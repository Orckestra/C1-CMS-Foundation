﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Composite.Data.DynamicTypes;
using Composite.Forms;
using Composite.Forms.WebChannel;
using Composite.Data.Types;
using Composite.Data;
using System.Collections.Generic;
using Composite.Data.GeneratedTypes;
using System.Xml;
using Composite.Functions;
using Microsoft.Practices.EnterpriseLibrary.Validation;
using Composite.Validation;
using Composite.Modules.FormsRenderer;

public partial class AddOns_FormsRenderer_FormsRender : System.Web.UI.UserControl
{
    
    private string errorMessage = "";

    public ParameterList parameters { get; set; }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        IntroText.Text = parameters.GetParameter<string>("IntroText");
        
        string sendButtonLabel = parameters.GetParameter<string>("SendButtonLabel");
        if (sendButtonLabel != string.Empty)
            Send.Text = sendButtonLabel;
        
        string resetButtonLabel = parameters.GetParameter<string>("ResetButtonLabel");
        Reset.Value = resetButtonLabel;
        if (resetButtonLabel == string.Empty)
            Reset.Visible = false;


        FormsRenderer.InsertForm(this.Fields,parameters);

        

        
    }

    protected void Send_Click(object sender, EventArgs e)
    {
        

        if (FormsRenderer.SubmitForm())
        {
            string responseText = parameters.GetParameter<string>("ResponseText");
            string responseUrl = parameters.GetParameter<string>("ResponseUrl");
            if (responseUrl != string.Empty)
            {
                Response.Redirect(responseUrl);
            }
            IntroText.Text = responseText;
            Fields.Visible = false;
            FieldSet.Visible = false;
        }


    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (errorMessage != string.Empty) 
            args.IsValid = false;
    }
}
